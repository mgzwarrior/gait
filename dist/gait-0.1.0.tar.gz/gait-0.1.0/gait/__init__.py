"""
gait.

A git AI productivity tool.
"""

__version__ = "0.1.0"
__author__ = 'Matt Grant'
